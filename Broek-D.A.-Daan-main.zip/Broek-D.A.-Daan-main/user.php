<?php
require("classes/userClass.php");

// er word een user gemaakt met de connectie erin
$gebruikersnaam  = isset($_POST['gebruikersnaam ']) ? $_POST['gebruikersnaam '] : null;
$voornaam = isset($_POST['voornaam']) ? $_POST['voornaam'] : null;
$tussenvoegsel = isset($_POST['tussenvoegsel']) ? $_POST['tussenvoegsel'] : null;
$achternaam = isset($_POST['achternaam']) ? $_POST['achternaam'] : null;
$exameninformatie = isset($_POST['exameninformatie']) ? $_POST['exameninformatie'] : null;

$user = new user($conn, $gebruikersnaam , $voornaam, $tussenvoegsel, $achternaam, $exameninformatie);

// verwerking van een formulier waarin gebruikers informatie over een auto kunnen bewerken
if (isset($_POST['save_edit'])) {
    $editId = $_POST['editId'];

    $newGebruikersnaam = $_POST['newGebruikersnaam'];
    $newVoornaam = $_POST['newVoornaam'];
    $newTussenvoegsel = $_POST['newTussenvoegsel'];
    $newAchternaam = $_POST['newAchternaam'];
    $newExameninformatie = $_POST['newExameninformatie'];

    $updateResult = $user->userAanpassen($editId, $newGebruikersnaam, $newVoornaam, $newTussenvoegsel, $newAchternaam, $newExameninformatie);

    if ($updateResult) {
        $successMessage = 'User succesvol aangepast.';
    } else {
        $errorMessage = 'Er is een fout opgetreden bij het aanpassen van de user.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/css.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Persoongegevens</title>
</head>
<body>
<!-- navigatie -->
<div class="nav-container">
        <div class="nav-buttons">
            <div class="nav-button"><button class="nv-btn" onclick="location.href='index.php'" type="button">Home</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='wagenpark.php'" type="button">Wagenpark beheren</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='les.php'" type="button">lessen</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='user.php'" type="button">Persoongegevens aanpassen</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='inlog.php'" type="button">login</button></div>
        </div>
    </div>
</body>
</head>


<!-- user bewerken form -->
<form method="post" action="#">
    <?php
    // kijk of de 'edit' key in de post array zit
    if (isset($_POST['edit'])) {
        $editId = $_POST['edit'];

        // roep getUserDetails aan
        $userDetails = $user->getUserDetails($editId);

        // echo de form voor bewerken
        if ($userDetails) {
            echo '<label for="newGebruikersnaam">New Gebruikersnaam:</label>
                <input type="text" name="newGebruikersnaam" required value="' . $userDetails['gebruikersnaam'] . ' ">
                <label for="newVoornaam">New Voornaam:</label>
                <input type="text" name="newVoornaam" required value="' . $userDetails['voornaam'] . '">
                <label for="newTussenvoegsel">New Tussenvoegsel:</label>
                <input type="text" name="newTussenvoegsel" value="' . $userDetails['tussenvoegsel'] . '">
                <label for="newAchternaam">New Achternaam:</label>
                <input type="text" name="newAchternaam" required value="' . $userDetails['achternaam'] . '">
                <label for="newExameninformatie">New Exameninformatie:</label>
                <input type="text" name="newExameninformatie" required value="' . $userDetails['exameninformatie'] . '">
                <input type="hidden" name="editId" value="' . $editId . '">
                <input type="submit" value="Save" name="save_edit">';
        } else {
            echo "Error: Unable to retrieve user details for editing.";
            echo "Edit ID: $editId"; // Debugging line
        }
    }
    ?>
</form>

    

<?php
    
// kijkt of er een page in de url staat zo niet dan word de page 1 anders dan word het de variabele $page
$page = isset($_GET['page']) ? $_GET['page'] : 1;
// behBekijken oproepen
$user->userLatenZien($page);
?>
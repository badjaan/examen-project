<?php 
require("classes/wagenparkClass.php");

// er word een auto gemaakt met de connectie erin
$merk = isset($_POST['merk']) ? $_POST['merk'] : null;
$kenteken = isset($_POST['kenteken']) ? $_POST['kenteken'] : null;
$soort = isset($_POST['soort']) ? $_POST['soort'] : null;

$auto = new auto($conn, $merk, $kenteken, $soort);


$successMessage = '';
$errorMessage = '';
// als de submit knop is ingedrukt dan voert die functie autoToevoegen uit en redirect naar zichzelf
if (isset($_POST['submit'])) {
    $auto->autoToevoegen();
    header("Location: ".$_SERVER['PHP_SELF']."?success=add");
    exit;
}

// als de delete knop is ingedrukt dan roept die autoVerwijderen aan
if (isset($_POST['delete'])) {
    $deleteId = $_POST['delete'];
    $deleteResult = $auto->autoVerwijderen($deleteId);

    if ($deleteResult) {
        $successMessage = 'Auto succesvol verwijderd.';
    } else {
        $errorMessage = 'Er is een fout opgetreden bij het verwijderen van de auto.';
    }
}

// verwerking van een formulier waarin gebruikers informatie over een auto kunnen bewerken
if (isset($_POST['save_edit'])) {
    $editId = $_POST['editId'];
    $newMerk = $_POST['newMerk'];
    $newKenteken = $_POST['newKenteken'];
    $newType = $_POST['newType'];

    $updateResult = $auto->autoAanpassen($editId, $newMerk, $newKenteken, $newType);

    if ($updateResult) {
        $successMessage = 'Auto succesvol aangepast.';
    } else {
        $errorMessage = 'Er is een fout opgetreden bij het aanpassen van de auto.';
    }
}


?>



<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/css.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wagenpark</title>
</head>
<body>
<!-- navigatie -->
<div class="nav-container">
        <div class="nav-buttons">
            <div class="nav-button"><button class="nv-btn" onclick="location.href='index.php'" type="button">Home</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='wagenpark.php'" type="button">Wagenpark beheren</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='les.php'" type="button">lessen</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='user.php'" type="button">Persoongegevens aanpassen</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='inlog.php'" type="button">login</button></div>
        </div>
    </div>

    <button class="nv-btn" onclick="document.getElementById('autoToevoegenForm').style.display = 'block';">Auto Toevoegen</button>

<!-- auto toevoegen form -->
<form method="POST" id="autoToevoegenForm" style="display: none;">
    <div class="form-group">
        <label for="beschrijving">Auto Toevoegen:</label>
    </div>
    <div class="form-group">
        <label for="merk">merk:</label>
        <input type="text" id="merk" name="merk" placeholder="Voer het merk in" required>
    </div>
    <div class="form-group">
        <label for="kenteken">kenteken:</label>
        <input type="text" id="kenteken" name="kenteken" placeholder="Voer het kenteken in" required>
    </div>
    <select id="soort" name="soort">
        <option value="1" >Race</option>
        <option value="2">Sadan</option>
        <option value="3" >Stationwagon</option>
        <option value="4">Coupe</option>
    </select>
    <div class="form-group">
        <input type="submit" value="Voeg toe" id="submit" name="submit">
    </div>
</form>


<!-- auto bewerken form -->
<form method="post" action="#">
    <?php
    // kijk of de 'edit' key in de post array zit
    if (isset($_POST['edit'])) {
        $editId = $_POST['edit'];

        // roep getAutoDetails aan
        $autoDetails = $auto->getAutoDetails($editId);

        // echo de form voor bewerken
        if ($autoDetails) {
            echo '<label for="newMerk">New Merk:</label>
                <input type="text" name="newMerk" value="' . $autoDetails['merk'] . '">
                <label for="newKenteken">New Kenteken:</label>
                <input type="text" name="newKenteken" value="' . $autoDetails['kenteken'] . '">
                <label for="newType">New Type:</label>
                <select id="newType" name="newType">
                    <option value="1" ' . ($autoDetails['type'] == 1 ? 'selected' : '') . '>Race</option>
                    <option value="2" ' . ($autoDetails['type'] == 2 ? 'selected' : '') . '>Sadan</option>
                    <option value="3" ' . ($autoDetails['type'] == 3 ? 'selected' : '') . '>Stationwagon</option>
                    <option value="4" ' . ($autoDetails['type'] == 4 ? 'selected' : '') . '>Coupe</option>
                </select>
                <input type="hidden" name="editId" value="' . $editId . '">
                <input type="submit" value="Save" name="save_edit">';
        } else {
            echo "Error: Unable to retrieve auto details for editing.";
        }
    }
    ?>
</form>



<?php if (isset($successMessage)): ?>
    <div class="success-message"><?php echo $successMessage; ?></div>
<?php endif; ?>

<?php if (isset($errorMessage)): ?>
    <div class="error-message"><?php echo $errorMessage; ?></div>
<?php endif; ?>

<?php
    
// kijkt of er een page in de url staat zo niet dan word de page 1 anders dan word het de variabele $page
$page = isset($_GET['page']) ? $_GET['page'] : 1;
// behBekijken oproepen
$auto->autoLatenZien($page);
?>

</body>
</head>

    
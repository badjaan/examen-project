
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/css.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
<!-- navigatie -->
<div class="nav-container">
        <div class="nav-buttons">
            <div class="nav-button"><button class="nv-btn" onclick="location.href='index.php'" type="button">Home</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='wagenpark.php'" type="button">Wagenpark beheren</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='les.php'" type="button">lessen</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='user.php'" type="button">Persoongegevens aanpassen</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='inlog.php'" type="button">login</button></div>
        </div>
    </div>

    <?php
session_start(); 

if(!isset($_SESSION['ingelogd'])) {
    header("location: inlog.php");
    exit();
}

if (isset($_SESSION['ingelogd']) && $_SESSION['ingelogd']) {
    echo "<p>User is logged in. Role: " . $_SESSION['rol'] . "</p>";

    if ($_SESSION['rol'] == 1) {
        echo "<h1>hallo klant</h1>";
    } elseif ($_SESSION['rol'] == 2) {
        echo "<h1>hallo eigenaar</h1>";
    } else {
        echo "<p>Unknown role</p>";
    }
} else {
    echo "<p>User is not logged in</p>";
}

if (isset($_GET['message'])) {
    $message = urldecode($_GET['message']);
    echo "<p>$message</p>";
}
?>



    <p>doe maar alsof dit een hele mooie home page is</p>

    <!-- Logout button -->
<form method="post" action="logout.php" class="logout-form">
    <input type="submit" value="Logout">
</form>

</body>
</head>

    
<?php

class database {
    public $conn;
// connectie met database
    public function connect() {
        try {
            $this->conn = new PDO("mysql:host=localhost;dbname=autorijschool", "root", "");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->conn;
        } catch (PDOException $e) {
            echo 'Connection failed: '  . $e->getMessage();
        }
    }
}
// instanties van database maken en oproepen
$db = new database();
$conn = $db->connect();

?>
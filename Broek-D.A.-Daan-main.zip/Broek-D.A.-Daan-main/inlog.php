<?php

require_once('classes/dbstart.php');

class UserInlog
{
    private $connection;

    public function __construct($connection)
    {
        $this->connection = $connection;
    }

    public function loginUser($gebruikersnaam, $wachtwoord)
    {
        try {
            $stmt = $this->connection->prepare("SELECT gebruikersnaam, wachtwoord, gebruiker_id, rol FROM gebruiker WHERE gebruikersnaam = :gebruikersnaam");
            $stmt->bindParam(':gebruikersnaam', $gebruikersnaam);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($wachtwoord, $user['wachtwoord'])) {
                // Set de informatie van de user in de sessie
                session_start();
                $_SESSION['gebruiker_id'] = $user['gebruiker_id'];
                $_SESSION['gebruikersnaam'] = $gebruikersnaam;
                $_SESSION['ingelogd'] = true;
                $_SESSION['rol'] = $user['rol'];
            
                header("Location: index.php");
                exit();
            } else {
                $message = "<p class='message'>log opnieuw in</p>";
            }

            return false;
        } catch (PDOException $e) {
            error_log($e->getMessage(), 0);
            return false;
        }
    }
}

$db = new database();
$conn = $db->connect();
$user = new UserInlog($conn);

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gebruikersnaam = $_POST["gebruikersnaam"];
    $wachtwoord = $_POST["wachtwoord"];

    if ($user->loginUser($gebruikersnaam, $wachtwoord)) {
        session_start();
        $_SESSION['gebruikersnaam'] = $gebruikersnaam;

        $_SESSION['ingelogd'] = true;

        header("Location: index.php");
        exit();
    } else {
        $message = "<p class='message'>log opnieuw in</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/css.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login Form</title>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form-group">
        <label>Login</label>
        <label for="gebruikersnaam">gebruikersnaam:</label>
        <input type="text" name="gebruikersnaam" required><br>

        <label for="wachtwoord">wachtwoord:</label>
        <input type="password" name="wachtwoord" required><br>

        <input type="submit" value="Login">
    </form>

    <div class="nav-button"><button class="nv-btn" onclick="location.href='register.php'" type="button">nog geen account?</button></div>

    <?php echo $message; ?>

</body>
</html>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 30 jan 2024 om 16:28
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autorijschool`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `auto`
--

CREATE TABLE `auto` (
  `auto_id` int(10) NOT NULL,
  `merk` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `kenteken` varchar(255) DEFAULT NULL,
  `soortsoort_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `auto`
--

INSERT INTO `auto` (`auto_id`, `merk`, `model`, `kenteken`, `soortsoort_id`) VALUES
(42, 'mercedes', NULL, '6374-9374', 1),
(45, 'audi', NULL, '7547-jf73', 2),
(46, 'audi', NULL, '7547-jf73', 3);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `gebruiker`
--

CREATE TABLE `gebruiker` (
  `gebruiker_id` int(10) NOT NULL,
  `gebruikersnaam` varchar(255) DEFAULT NULL,
  `wachtwoord` varchar(255) DEFAULT NULL,
  `voornaam` varchar(255) DEFAULT NULL,
  `tussenvoegsel` varchar(50) DEFAULT NULL,
  `achternaam` varchar(255) DEFAULT NULL,
  `rol` int(1) DEFAULT NULL,
  `exameninformatie` text DEFAULT NULL,
  `actief` int(1) DEFAULT NULL,
  `geslaagd` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `gebruiker`
--

INSERT INTO `gebruiker` (`gebruiker_id`, `gebruikersnaam`, `wachtwoord`, `voornaam`, `tussenvoegsel`, `achternaam`, `rol`, `exameninformatie`, `actief`, `geslaagd`) VALUES
(1, 'daan   ', '$2y$10$Sq2Xfup8LHk9mDb3mPly..7aESe6nz2YYFohU4TXbazgAuuCUrHl2', 'daan', '', 'broek', 1, 'ja', NULL, NULL),
(2, 'q', '$2y$10$m6MYKH7ThaFEqY058qerLe5tq5DZ1dKIB.D4kky4KhkAC81uuLhOe', 'q', 'q', 'q', 1, 'q', NULL, NULL),
(3, 'hal', '$2y$10$gJXOd.i3P2YB/3GSUJIBMOszQuHJKjI1shTx.VJpieBHEUlCWgShe', 'hal', 'hal', 'hal', 1, 'hal', NULL, NULL),
(4, 'geb', '$2y$10$Mtq/nKCMkVJZ8Ci3WPOIyellyVh9hFqWihdHa4taEH1fb26atcpNK', 'geb', 'geb', 'geb', 1, 'geb', NULL, NULL),
(5, 'eigenaar', '$2y$10$RvJFwcQmTT89W1RkU1ptZu077GHnGAmgFidKJAAxsSdykW2IwWljW', 'eigenaar', 'eigenaar', 'eigenaar', 2, 'eigenaar', NULL, NULL),
(6, 'test', '$2y$10$FB91k7fYdmauaLeNL5iaPOvehgubcFa1FCNoxCUeOgeGCfRP5h2H2', 'test', 'test', 'test', 1, 'test', NULL, NULL),
(7, 'daan', '$2y$10$v29ZXlRsVcaXl/w5LGpSYeSPLrAmPzwqABzWzmSXE.Nta1KsrfD0y', 'gtgt', 'gt', 'gttg', 1, 'tgt', NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `gebruiker_lespakket`
--

CREATE TABLE `gebruiker_lespakket` (
  `gebruiker_lespakket_id` int(10) NOT NULL,
  `gebruikergebruiker_id` int(10) DEFAULT NULL,
  `lespakketlespakket_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `les`
--

CREATE TABLE `les` (
  `les_id` int(10) NOT NULL,
  `lestijd` datetime DEFAULT NULL,
  `ophaallocatieophaallocatie_id` int(10) DEFAULT NULL,
  `instructeur_id` int(10) DEFAULT NULL,
  `doel` text DEFAULT NULL,
  `opmerking_student` text DEFAULT NULL,
  `opmerking_instructeur` text DEFAULT NULL,
  `lespakket_id` int(10) DEFAULT NULL,
  `geannuleerd` int(1) DEFAULT NULL,
  `redenannuleren` text DEFAULT NULL,
  `autoauto_id` int(10) DEFAULT NULL,
  `adres` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `les`
--

INSERT INTO `les` (`les_id`, `lestijd`, `ophaallocatieophaallocatie_id`, `instructeur_id`, `doel`, `opmerking_student`, `opmerking_instructeur`, `lespakket_id`, `geannuleerd`, `redenannuleren`, `autoauto_id`, `adres`) VALUES
(1, '0000-00-00 00:00:00', NULL, 3, 'ja', 'ja', 'ja', 2, 0, 'none', 42, 'vechtstroom');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `lespakket`
--

CREATE TABLE `lespakket` (
  `lespakket_id` int(10) NOT NULL,
  `naam` varchar(100) DEFAULT NULL,
  `omschrijving` text DEFAULT NULL,
  `aantal` int(3) DEFAULT NULL,
  `prijs` decimal(15,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `lespakket`
--

INSERT INTO `lespakket` (`lespakket_id`, `naam`, `omschrijving`, `aantal`, `prijs`) VALUES
(1, 'losse les', 'dit is gewoon een losse les', 1, 100.00),
(2, 'autorijden voor noobs', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt mauris ut ex fringilla, ac vehicula neque pharetra. In hac habitasse platea dictumst. Integer aliquam, libero et vestibulum convallis, eros mi fermentum justo,', 5, 595.00);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `les_onderwerp`
--

CREATE TABLE `les_onderwerp` (
  `lesles_id` int(10) NOT NULL,
  `onderwerponderwerp_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `onderwerp`
--

CREATE TABLE `onderwerp` (
  `onderwerp_id` int(10) NOT NULL,
  `onderwerp` varchar(255) DEFAULT NULL,
  `omschrijving` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `onderwerp`
--

INSERT INTO `onderwerp` (`onderwerp_id`, `onderwerp`, `omschrijving`) VALUES
(1, 'stoplichten', 'stoplichten');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `ophaallocatie`
--

CREATE TABLE `ophaallocatie` (
  `ophaallocatie_id` int(10) NOT NULL,
  `adres` varchar(255) DEFAULT NULL,
  `postcode` varchar(6) DEFAULT NULL,
  `plaats` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `ophaallocatie`
--

INSERT INTO `ophaallocatie` (`ophaallocatie_id`, `adres`, `postcode`, `plaats`) VALUES
(1, 'drente 23', '8474gf', 'drente'),
(2, '123 Main St', '12345', 'Cityville');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `soort`
--

CREATE TABLE `soort` (
  `soort_id` int(10) NOT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `soort`
--

INSERT INTO `soort` (`soort_id`, `type`) VALUES
(1, 'race'),
(2, 'Sedan'),
(3, 'stationwagon'),
(4, 'coupe');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `ziekmelding`
--

CREATE TABLE `ziekmelding` (
  `ziekmelding_id` int(10) NOT NULL,
  `van` date DEFAULT NULL,
  `tot` date DEFAULT NULL,
  `toelichting` text DEFAULT NULL,
  `gebruikergebruiker_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `auto`
--
ALTER TABLE `auto`
  ADD PRIMARY KEY (`auto_id`),
  ADD KEY `soortsoort_id` (`soortsoort_id`);

--
-- Indexen voor tabel `gebruiker`
--
ALTER TABLE `gebruiker`
  ADD PRIMARY KEY (`gebruiker_id`);

--
-- Indexen voor tabel `gebruiker_lespakket`
--
ALTER TABLE `gebruiker_lespakket`
  ADD PRIMARY KEY (`gebruiker_lespakket_id`),
  ADD KEY `gebruikergebruiker_id` (`gebruikergebruiker_id`),
  ADD KEY `lespakketlespakket_id` (`lespakketlespakket_id`);

--
-- Indexen voor tabel `les`
--
ALTER TABLE `les`
  ADD PRIMARY KEY (`les_id`),
  ADD KEY `ophaallocatieophaallocatie_id` (`ophaallocatieophaallocatie_id`),
  ADD KEY `instructeur_id` (`instructeur_id`),
  ADD KEY `lespakket_id` (`lespakket_id`),
  ADD KEY `autoauto_id` (`autoauto_id`);

--
-- Indexen voor tabel `lespakket`
--
ALTER TABLE `lespakket`
  ADD PRIMARY KEY (`lespakket_id`);

--
-- Indexen voor tabel `les_onderwerp`
--
ALTER TABLE `les_onderwerp`
  ADD PRIMARY KEY (`lesles_id`,`onderwerponderwerp_id`),
  ADD KEY `onderwerponderwerp_id` (`onderwerponderwerp_id`);

--
-- Indexen voor tabel `onderwerp`
--
ALTER TABLE `onderwerp`
  ADD PRIMARY KEY (`onderwerp_id`);

--
-- Indexen voor tabel `ophaallocatie`
--
ALTER TABLE `ophaallocatie`
  ADD PRIMARY KEY (`ophaallocatie_id`);

--
-- Indexen voor tabel `soort`
--
ALTER TABLE `soort`
  ADD PRIMARY KEY (`soort_id`);

--
-- Indexen voor tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  ADD PRIMARY KEY (`ziekmelding_id`),
  ADD KEY `gebruikergebruiker_id` (`gebruikergebruiker_id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `auto`
--
ALTER TABLE `auto`
  MODIFY `auto_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT voor een tabel `gebruiker`
--
ALTER TABLE `gebruiker`
  MODIFY `gebruiker_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT voor een tabel `gebruiker_lespakket`
--
ALTER TABLE `gebruiker_lespakket`
  MODIFY `gebruiker_lespakket_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `les`
--
ALTER TABLE `les`
  MODIFY `les_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `lespakket`
--
ALTER TABLE `lespakket`
  MODIFY `lespakket_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `onderwerp`
--
ALTER TABLE `onderwerp`
  MODIFY `onderwerp_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `ophaallocatie`
--
ALTER TABLE `ophaallocatie`
  MODIFY `ophaallocatie_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT voor een tabel `soort`
--
ALTER TABLE `soort`
  MODIFY `soort_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  MODIFY `ziekmelding_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `auto`
--
ALTER TABLE `auto`
  ADD CONSTRAINT `auto_ibfk_1` FOREIGN KEY (`soortsoort_id`) REFERENCES `soort` (`soort_id`);

--
-- Beperkingen voor tabel `gebruiker_lespakket`
--
ALTER TABLE `gebruiker_lespakket`
  ADD CONSTRAINT `gebruiker_lespakket_ibfk_1` FOREIGN KEY (`gebruikergebruiker_id`) REFERENCES `gebruiker` (`gebruiker_id`),
  ADD CONSTRAINT `gebruiker_lespakket_ibfk_2` FOREIGN KEY (`lespakketlespakket_id`) REFERENCES `lespakket` (`lespakket_id`);

--
-- Beperkingen voor tabel `les`
--
ALTER TABLE `les`
  ADD CONSTRAINT `les_ibfk_1` FOREIGN KEY (`ophaallocatieophaallocatie_id`) REFERENCES `ophaallocatie` (`ophaallocatie_id`),
  ADD CONSTRAINT `les_ibfk_2` FOREIGN KEY (`instructeur_id`) REFERENCES `gebruiker` (`gebruiker_id`),
  ADD CONSTRAINT `les_ibfk_3` FOREIGN KEY (`lespakket_id`) REFERENCES `lespakket` (`lespakket_id`),
  ADD CONSTRAINT `les_ibfk_4` FOREIGN KEY (`autoauto_id`) REFERENCES `auto` (`auto_id`);

--
-- Beperkingen voor tabel `les_onderwerp`
--
ALTER TABLE `les_onderwerp`
  ADD CONSTRAINT `les_onderwerp_ibfk_1` FOREIGN KEY (`lesles_id`) REFERENCES `les` (`les_id`),
  ADD CONSTRAINT `les_onderwerp_ibfk_2` FOREIGN KEY (`onderwerponderwerp_id`) REFERENCES `onderwerp` (`onderwerp_id`);

--
-- Beperkingen voor tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  ADD CONSTRAINT `ziekmelding_ibfk_1` FOREIGN KEY (`gebruikergebruiker_id`) REFERENCES `gebruiker` (`gebruiker_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
require_once('dbstart.php');


// sessie start zodat ik niet zonder in te loggen hierheen kan
session_start();
if(!isset($_SESSION['ingelogd'])) {
    header("location: inlog.php");
    exit();
}

if (isset($_SESSION['rol']) && $_SESSION['rol'] == 2) {
    // word binnengelaten
} else {
    $message = "Je moet eigenaar zijn om deze pagina te bezoeken";
    header("location: index.php?message=" . urlencode($message));
    exit(); // Zorg ervoor dat het script stopt na het doorsturen
}

class auto {
    // connection en het max aantal rows per page
    private $connection;
    private $autosPerPage = 5;
    
    // eigenshappen
    private $merk;
    private $kenteken;
    private $soort;

    
    public function __construct($connection, $merk = null, $kenteken = null, $soort = null) {
        $this->connection = $connection;
        $this->merk = $merk;
        $this->kenteken = $kenteken;
        $this->soort = $soort;
    }

    // hier haalt die het totaal aantal autos op
    private function getTotalAutos() {
        $query = "SELECT COUNT(*) as total FROM auto";
        $result = $this->connection->query($query);
        $row = $result->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }

// haalt alle autos uit gettotalautos() en rekent dan uit hoeveel rows er zijn en laat de dan knoppen zien voor het veranderen van pages
    private function displayPagination($currentPage) {
        $totalAutos = $this->getTotalAutos();
        $totalPages = ceil($totalAutos / $this->autosPerPage); 

        // de knoppen voor het veranderen van de page
        echo '<div class="pagination">';
        for ($i = 1; $i <= $totalPages; $i++) {
            $activeClass = ($i === $currentPage) ? 'active' : '';
            echo '<a class="' . $activeClass . '" href="?page=' . $i . '">' . $i . '</a>';
        }
        echo '</div>';
    }

// alle autos weergeven in een tabel met verwijder en bewerk knoppen
    public function autoLatenZien($page = 1) {
        try {
            $offset = ($page - 1) * $this->autosPerPage;
            $query = "SELECT auto.*, soort.type 
                      FROM auto
                      LEFT JOIN soort ON auto.soortsoort_id = soort.soort_id
                      ORDER BY auto.auto_id DESC 
                      LIMIT $this->autosPerPage 
                      OFFSET $offset";
            $result = $this->connection->query($query);
    
            if ($result !== false) {
                $rows = $result->fetchAll(PDO::FETCH_ASSOC);
    // echo de tabel
                if (!empty($rows)) {
                    echo '<table>';
                    echo '<tr>';
                    echo '<th>merk</th>';
                    echo '<th>kenteken</th>';
                    echo '<th>type</th>';
                    echo '<th>delete</th>';
                    echo '<th>Edit</th>';
                    echo '</tr>';
    
                    foreach ($rows as $row) {
                        echo '<tr>';
                        echo '<td class="title">' . $row['merk'] . '</td>';
                        echo '<td class="description">' . $row['kenteken'] . '</td>';
                        echo '<td class="description">' . $row['type'] . '</td>';
                            $autoId = isset($row['auto_id']) ? $row['auto_id'] : '';
                            // knoppen die het id opslaan in de value
                        echo '<td>
                                <form method="post" action="">
                                    <input type="hidden" name="delete" value="' . $autoId . '">
                                    <input type="submit" value="Verwijderen">
                                </form>
                              </td>';
                        echo '<td>
                                <form method="post" action="#">
                                    <input type="hidden" name="edit" value="' . $autoId . '">
                                    <input type="submit" value="bewerk">
                                </form>
                            </td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                    echo '<br>';
                    // hier roept die de displaypaginatie functie aan zodat de paginatie knoppen onder de tabel komen
                    $this->displayPagination($page);
                } else {
                    // een bericht als er geen rows zijn
                    echo 'Geen auto\'s gevonden.';
                }
        } 
    } catch (Exception $e) {
        echo 'Er is een fout opgetreden: ' . $e->getMessage();
    }
    }

// voegd ingevulde waarden aan de database toe
    public function autoToevoegen() {
        try {
            $insertQuery = "INSERT INTO auto (merk, kenteken, soortsoort_id) VALUES (:merk, :kenteken, :soort)";
            $stmt = $this->connection->prepare($insertQuery);

            // Bind values aan de placeholders
            $stmt->bindValue(':merk', $this->merk);
            $stmt->bindValue(':kenteken', $this->kenteken);
            $stmt->bindValue(':soort', $this->soort, PDO::PARAM_INT);

            $insertResult = $stmt->execute();

        } catch (PDOException $e) {
            throw new Exception("Error: " .  $e->getMessage());
        }
    }

    // haalt row op waar de data gelijk is aan het id van de row die is aangeklikt
    public function getAutoDetails($id) {
        try {
            $query = "SELECT auto.*, soort.type AS type FROM auto
                      LEFT JOIN soort ON auto.soortsoort_id = soort.soort_id
                      WHERE auto_id = :id";

            $stmt = $this->connection->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
    
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            throw new Exception("Error: " . $e->getMessage());
        }
    }
    // hier verandert die de data naar de nieuwe values die je hebt ingevoert
    public function autoAanpassen($id, $newMerk, $newKenteken, $newSoortId) {
        try {
            $updateQuery = "UPDATE auto 
                            SET merk = :newMerk, 
                                kenteken = :newKenteken, 
                                soortsoort_id = :newSoortId 
                            WHERE auto_id = :id";
    
            $updateStmt = $this->connection->prepare($updateQuery);
    
            $updateStmt->bindValue(':id', $id, PDO::PARAM_INT);
            $updateStmt->bindValue(':newMerk', $newMerk);
            $updateStmt->bindValue(':newKenteken', $newKenteken);
            $updateStmt->bindValue(':newSoortId', $newSoortId, PDO::PARAM_INT);
    
            $updateResult = $updateStmt->execute();
    
            return $updateResult;
        } catch (PDOException $e) {
            throw new Exception("Error: " . $e->getMessage());
        }
    }

// verwijdert een auto uit de database
     public function autoVerwijderen($id) {
        try {
            // Check of de auto voor een les wordt gebruikt in de komende 24 uur
            $checkLessonQuery = "SELECT COUNT(*) as lessonCount FROM les WHERE autoauto_id = :id AND lestijd >= NOW()";
            $checkLessonStmt = $this->connection->prepare($checkLessonQuery);
            $checkLessonStmt->bindValue(':id', $id, PDO::PARAM_INT);
            $checkLessonStmt->execute();
            $lessonCount = $checkLessonStmt->fetch(PDO::FETCH_ASSOC)['lessonCount'];
    
            if ($lessonCount > 0) {
                // als de auto nog een les heeft return dan false
                return false;
            } else {
                // zijn er geen lessen? ga dan door
                $deleteQuery = "DELETE FROM auto WHERE auto_id = :id";
                $stmt = $this->connection->prepare($deleteQuery);
    
                if ($stmt) {
                    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
                    $deleteResult = $stmt->execute();
                    $stmt->closeCursor();
    
                    return $deleteResult;
                }
            }
        } catch (Exception $e) {
            echo 'Er is een fout opgetreden: ' . $e->getMessage();
        }
    }

}

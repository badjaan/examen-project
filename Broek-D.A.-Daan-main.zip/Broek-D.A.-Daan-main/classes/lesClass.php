<?php
require_once('dbstart.php');
// sessie start zodat ik niet zonder in te loggen hierheen kan
session_start();
if(!isset($_SESSION['ingelogd'])) {
    header("location: inlog.php");
    exit();
}

if (isset($_SESSION['rol']) && $_SESSION['rol'] == 1) {
    // word binnengelaten
} else {
    $message = "Je moet klant zijn om deze pagina te bezoeken";
    header("location: index.php?message=" . urlencode($message));
    exit(); // Zorg ervoor dat het script stopt na het doorsturen
}


class les {
    private $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function lessenOphalen() {
        try {
            $query = "SELECT 
                        gebruiker.gebruikersnaam AS gebruiker_naam, 
                        les.lestijd, 
                        ophaallocatie.adres AS ophaaladres, 
                        les.doel, 
                        lespakket.aantal, 
                        les.opmerking_student, 
                        les.opmerking_instructeur, 
                        onderwerp.onderwerp
                    FROM les
                    LEFT JOIN gebruiker ON les.instructeur_id = gebruiker.gebruiker_id
                    LEFT JOIN ophaallocatie ON les.ophaallocatieophaallocatie_id = ophaallocatie.ophaallocatie_id
                    LEFT JOIN gebruiker_lespakket ON gebruiker.gebruiker_id = gebruiker_lespakket.gebruikergebruiker_id
                    LEFT JOIN lespakket ON gebruiker_lespakket.lespakketlespakket_id = lespakket.lespakket_id
                    LEFT JOIN les_onderwerp ON les.les_id = les_onderwerp.lesles_id
                    LEFT JOIN onderwerp ON les_onderwerp.onderwerponderwerp_id = onderwerp.onderwerp_id
                    ORDER BY les.lestijd DESC";
    
            $stmt = $this->connection->prepare($query);
            $stmt->execute();
    
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // alle data in tabel laten zien
            if (!empty($rows)) {
                echo '<table>';
                echo '<tr>';
                echo '<th>Instructeur/Leerling</th>';
                echo '<th>Lestijd</th>';
                echo '<th>Ophaaladres</th>';
                echo '<th>Doel</th>';
                echo '<th>Aantal</th>';
                echo '<th>Opmerking Student</th>';
                echo '<th>Opmerking Instructeur</th>';
                echo '<th>Onderwerp</th>';
                echo '</tr>';
    
                foreach ($rows as $row) {
                    echo '<tr>';
                    echo '<td>' . $row['gebruiker_naam'] . '</td>';
                    echo '<td>' . $row['lestijd'] . '</td>';
                    echo '<td>' . $row['ophaaladres'] . '</td>';
                    echo '<td>' . $row['doel'] . '</td>';
                    echo '<td>' . $row['aantal'] . '</td>';
                    echo '<td>' . $row['opmerking_student'] . '</td>';
                    echo '<td>' . $row['opmerking_instructeur'] . '</td>';
                    echo '<td>' . $row['onderwerp'] . '</td>';
                    echo '</tr>';
                }
    
                echo '</table>';
                echo '<br>';
            }
        } catch (Exception $e) {
            echo 'Er is een fout opgetreden: ' . $e->getMessage();
        }
    }
    }
    



?>

    
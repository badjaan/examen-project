<?php
require_once('dbstart.php');

// sessie start zodat ik niet zonder in te loggen hierheen kan
session_start();
if(!isset($_SESSION['ingelogd'])) {
    header("location: inlog.php");
    exit();
}

class lesPakket {
    private $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function lesPakkettenOphalen() {
        try {
            $query = "SELECT * FROM lespakket ORDER BY lespakket_id DESC";
            $result = $this->connection->query($query);
    
            if ($result !== false) {
                $rows = $result->fetchAll(PDO::FETCH_ASSOC);
    // echo de tabel
                if (!empty($rows)) {
                    foreach ($rows as $row) {
                        echo '<table>';
                        echo '<tr>';
                        echo '<th>Naam</th>';
                        echo '<th>omschrijving</th>';
                        echo '<th>aantal</th>';
                        echo '<th>prijs</th>';
                        echo '</tr>';

                        echo '<tr>';
                        echo '<td class="title">' . $row['naam'] . '</td>';
                        echo '<td class="description">' . $row['omschrijving'] . '</td>';
                        echo '<td class="description">' . $row['aantal'] . '</td>';
                        echo '<td class="description">' . $row['prijs'] . '</td>';
                        
                        echo '</table>';
                        echo '<br>';

                        $lespakket_id = $row['lespakket_id'];
                        echo '<form action="index.php" method="post">';
                        echo '<input type="hidden" name="lespakket_id" value="' . $lespakket_id . '">';
                        echo '<td class="description"><button type="submit">Add to Les</button></td>';
                        echo '</form>';

                    }
                }
        } 
    } catch (Exception $e) {
        echo 'Er is een fout opgetreden: ' . $e->getMessage();
    }
    }


}



?>

    
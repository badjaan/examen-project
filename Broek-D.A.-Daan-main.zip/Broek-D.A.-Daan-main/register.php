<?php
require_once('classes/dbstart.php');


class UserRegister
{
    private $connection;

    public function __construct($connection)
    {
        $this->connection = $connection;
    }

      // Functie om gebruiker te registreren
    public function registerUser($gebruikersnaam, $wachtwoord, $voornaam, $tussenvoegsel, $achternaam, $exameninformatie)
    {
        try {
            $stmt = $this->connection->prepare("INSERT INTO gebruiker (gebruikersnaam,wachtwoord ,voornaam ,tussenvoegsel ,achternaam ,exameninformatie, rol) VALUES (:gebruikersnaam, :wachtwoord, :voornaam, :tussenvoegsel, :achternaam, :exameninformatie, 1)");

           
            $stmt->bindParam(':gebruikersnaam', $gebruikersnaam);
            $stmt->bindParam(':wachtwoord', $wachtwoord);
            $stmt->bindParam(':voornaam', $voornaam);
            $stmt->bindParam(':tussenvoegsel', $tussenvoegsel);
            $stmt->bindParam(':achternaam', $achternaam);
            $stmt->bindParam(':exameninformatie', $exameninformatie);

            $stmt->execute();

            return true;
        } catch (PDOException $e) {
            error_log($e->getMessage(), 0);
            return false;
        }
    }
}
// Functie om door te verwijzen naar het inlogscherm
function redirectToLogin()
{
    header("Location: inlog.php");
    exit();
}
// Functie voor het weergeven van berichten
function displayMessage($message)
{
    echo "<p class='message'>$message</p>";
}


$db = new database();
$conn = $db->connect();
$user = new UserRegister($conn);

// Gegevens verwerken bij het indienen van het formulier
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gebruikersnaam = $_POST["gebruikersnaam"];
    $wachtwoord = password_hash($_POST["wachtwoord"], PASSWORD_BCRYPT);
    $voornaam = $_POST["voornaam"];
    $tussenvoegsel = $_POST["tussenvoegsel"];
    $achternaam = $_POST["achternaam"];
    $exameninformatie = $_POST["exameninformatie"];

     // Gebruiker registreren en bericht weergeven
    if ($user->registerUser($gebruikersnaam, $wachtwoord, $voornaam, $tussenvoegsel, $achternaam, $exameninformatie)) {
        displayMessage("Data inserted into the database successfully.");
        redirectToLogin();
    } else {
        displayMessage("Error inserting data into the database.");
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/css.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration Form</title>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form-group">
        <label>Registratie</label>
        <label for="gebruikersnaam">gebruikersnaam:</label>
        <input type="text" name="gebruikersnaam" required><br>

        <label for="wachtwoord">wachtwoord:</label>
        <input type="password" name="wachtwoord" required><br>

        <label for="voornaam">voornaam:</label>
        <input type="text" name="voornaam" required><br>

        <label for="tussenvoegsel">tussenvoegsel:</label>
        <input type="text" name="tussenvoegsel"><br>

        <label for="achternaam">achternaam:</label>
        <input type="text" name="achternaam" required><br>

        <label for="exameninformatie">exameninformatie:</label>
        <input type="text" name="exameninformatie" required><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
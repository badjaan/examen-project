<?php require("classes/lesClass.php");?>


<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/css.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Les</title>
</head>
<body>
<!-- navigatie -->
<div class="nav-container">
        <div class="nav-buttons">
            <div class="nav-button"><button class="nv-btn" onclick="location.href='index.php'" type="button">Home</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='wagenpark.php'" type="button">Wagenpark beheren</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='les.php'" type="button">lessen</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='user.php'" type="button">Persoongegevens aanpassen</button></div>
            <div class="nav-button"><button class="nv-btn" onclick="location.href='inlog.php'" type="button">login</button></div>
        </div>
    </div>

    <div class="nav-button"><button class="nv-btn" onclick="location.href='lespakket.php'" type="button">Persoongegevens aanpassen</button></div>

    <?php
      
      $les = new les($conn);
      $les->lessenOphalen();
     
    ?>
</body>
</head>

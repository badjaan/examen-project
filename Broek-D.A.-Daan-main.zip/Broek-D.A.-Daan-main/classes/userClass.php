<?php
require_once('dbstart.php');


// sessie start zodat ik niet zonder in te loggen hierheen kan
session_start();
if(!isset($_SESSION['ingelogd'])) {
    header("location: inlog.php");
    exit();
}

if (isset($_SESSION['rol']) && $_SESSION['rol'] == 2) {
    // word binnengelaten
} else {
    $message = "Je moet eigenaar zijn om deze pagina te bezoeken";
    header("location: index.php?message=" . urlencode($message));
    exit(); // Zorg ervoor dat het script stopt na het doorsturen
}

 class user {
        // connection en het max aantal rows per page
    private $connection;
    private $usersPerPage = 5;

    public $gebruikersnaam;
    public $voornaam; 
    public $tussenvoegsel; 
    public $achternaam; 
    public $exameninformatie;

    public function __construct($connection, $gebruikersnaam = null, $voornaam = null, $tussenvoegsel = null, $achternaam = null, $exameninformatie = null) {
        $this->connection = $connection;
        $this->gebruikersnaam = $gebruikersnaam;
        $this->voornaam = $voornaam;
        $this->tussenvoegsel = $tussenvoegsel;
        $this->achternaam = $achternaam;
        $this->exameninformatie = $exameninformatie;
    }

       // hier haalt die het totaal aantal users op
       private function getTotalUsers() {
        $query = "SELECT COUNT(*) as total FROM gebruiker";
        $result = $this->connection->query($query);
        $row = $result->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }

// haalt alle users uit gettotalusers() en rekent dan uit hoeveel rows er zijn en laat de dan knoppen zien voor het veranderen van pages
    private function displayPagination($currentPage) {
        $totalUsers = $this->getTotalUsers();
        $totalPages = ceil($totalUsers / $this->usersPerPage); // staat in construct

        // de knoppen voor het veranderen van de page
        echo '<div class="pagination">';
        for ($i = 1; $i <= $totalPages; $i++) {
            $activeClass = ($i === $currentPage) ? 'active' : '';
            echo '<a class="' . $activeClass . '" href="?page=' . $i . '">' . $i . '</a>';
        }
        echo '</div>';
    }

// alle users weergeven in een tabel met verwijder en bewerk knoppen
    public function userLatenZien($page = 1) {
        try {
            $offset = ($page - 1) * $this->usersPerPage;
            $query = "SELECT * FROM gebruiker";
            $result = $this->connection->query($query);
    
            if ($result !== false) {
                $rows = $result->fetchAll(PDO::FETCH_ASSOC);
    // echo de tabel
                if (!empty($rows)) {
                    echo '<table>';
                    echo '<tr>';
                    echo '<th>gebruikersnaam</th>';
                    echo '<th>voornaam</th>';
                    echo '<th>tussenvoegsel</th>';
                    echo '<th>achternaam</th>';
                    echo '<th>exameninformatie</th>';
                    echo '<th>Edit</th>';
                    echo '</tr>';
    
                    foreach ($rows as $row) {
                        echo '<tr>';
                        echo '<td class="title">' . $row['gebruikersnaam'] . '</td>';
                        echo '<td class="description">' . $row['voornaam'] . '</td>';
                        echo '<td class="description">' . $row['tussenvoegsel'] . '</td>';
                        echo '<td class="description">' . $row['achternaam'] . '</td>';
                        echo '<td class="description">' . $row['exameninformatie'] . '</td>';
                            $gebruikerId = isset($row['gebruiker_id']) ? $row['gebruiker_id'] : '';
                            // knoppen die het id opslaan in de value
                        echo '<td>
                                <form method="post" action="#">
                                    <input type="hidden" name="edit" value="' . $gebruikerId . '">
                                    <input type="submit" value="bewerk">
                                </form>
                            </td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                    echo '<br>';
                    // hier roept die de displaypaginatie functie aan zodat de paginatie knoppen onder de tabel komen
                    $this->displayPagination($page);
                } else {
                    // een bericht als er geen rows zijn
                    echo 'Geen user\'s gevonden.';
                }
        } 
    } catch (Exception $e) {
        echo 'Er is een fout opgetreden: ' . $e->getMessage();
    }
    }


      // haalt row op waar de data gelijk is aan het id van de row die is aangeklikt
      public function getUserDetails($id) {
        try {
            $query = "SELECT * FROM gebruiker WHERE gebruiker_id = :id";

            $stmt = $this->connection->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
    
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            throw new Exception("Error: " . $e->getMessage());
        }
    }
    // hier verandert die de data naar de nieuwe values die je hebt ingevoert
    public function userAanpassen($id, $newGebruikersnaam , $newVoornaam, $newTussenvoegsel, $newAchternaam, $newExameninformatie) {
        try {
            $updateQuery = "UPDATE gebruiker 
            SET gebruikersnaam = :newGebruikersnaam, 
                voornaam = :newVoornaam, 
                tussenvoegsel = :newTussenvoegsel, 
                achternaam = :newAchternaam,
                exameninformatie = :newExameninformatie  -- Fix the missing comma here
            WHERE gebruiker_id = :id";
    
            $updateStmt = $this->connection->prepare($updateQuery);
    
            $updateStmt->bindValue(':id', $id, PDO::PARAM_INT);
$updateStmt->bindValue(':newGebruikersnaam', $newGebruikersnaam);
$updateStmt->bindValue(':newVoornaam', $newVoornaam);
$updateStmt->bindValue(':newTussenvoegsel', $newTussenvoegsel);
$updateStmt->bindValue(':newAchternaam', $newAchternaam);
$updateStmt->bindValue(':newExameninformatie', $newExameninformatie);
    
            $updateResult = $updateStmt->execute();
    
            return $updateResult;
        } catch (PDOException $e) {
            throw new Exception("Error: " . $e->getMessage());
        }
    }
 }